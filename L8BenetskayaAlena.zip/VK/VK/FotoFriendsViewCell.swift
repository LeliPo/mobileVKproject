//
//  FotoFriendsViewCell.swift
//  VK
//
//  Created by  Алёна Бенецкая on 03.10.17.
//  Copyright © 2017  Алёна Бенецкая. All rights reserved.
//

import UIKit

class FotoFriendsViewCell: UICollectionViewCell {
    
    @IBOutlet weak var fotoFrend: UIImageView!
}
